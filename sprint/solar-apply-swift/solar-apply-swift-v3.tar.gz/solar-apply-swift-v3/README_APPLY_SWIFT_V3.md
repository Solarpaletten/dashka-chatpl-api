# Solar Apply Swift — v3.0

**Human-in-the-loop incremental installer for Swift/Xcode.**

> Born from the May 2026 night session where 30 files in one bulk apply
> turned into 7 unfixable Xcode errors and a `pbxproj` we couldn't trust.
> The lesson cost a night. This installer is the consolidation of it.

---

## The Constitutional Model

```
┌────────────────────────────────────────────────────────────────────────┐
│            iOS Assembly Pipeline — Separation of Concerns              │
├────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  AI (Claude)                  INSTALLER             ARCHITECT (Leanid) │
│  ───────────                  ─────────             ─────────────────  │
│  ✓ Generates .swift content   ✓ Validates topology  ✓ Creates groups   │
│  ✓ Packages archive           ✓ Writes ONE file     ✓ Adds to target   │
│  ✓ Maintains dep order        ✓ Awaits build OK     ✓ Runs ⌘B          │
│                               ✓ Persists journal    ✓ Confirms green   │
│                               ✓ Rolls back on red   ✓ Final merge      │
│                                                                         │
│  Code can be generated.       Files can be applied. Graph cannot       │
│  Topology cannot.             Topology cannot.      be generated.      │
│                                                                         │
└────────────────────────────────────────────────────────────────────────┘
```

**Why this shape:** Xcode's `project.pbxproj` graph is hand-curated by
design. Automated edits via Ruby gems, XcodeGen, etc. all work — until
they don't, and then debugging takes a night. The cheapest invariant is
to **never let automation touch the graph**. Files yes, graph no.

---

## The Six-Step Loop

```
STEP 0  Architect creates Xcode groups manually (one time per sprint)
        ↓
STEP 1  Installer validates topology
        ↓ if missing: ❌ "Group Domain/Model not found" → STOP
        ↓
STEP 2  Architect creates missing group → continue
        ↓
STEP 3  Installer writes ONE file
        ↓
STEP 4  Architect: Add Files to "Dashka" → ⌘B
        ↓
STEP 5  Architect confirms build [Y/N/P]
        ↓ if red:  ↩ rollback this file only, journal preserved
        ↓ if pause: ⏸ save journal, exit, resume later
        ↓
STEP 6  Continue → next file
```

Every gate is interruptible. Every progress fact is journaled. Every
rollback is local to a single file. No file is ever lost to a bulk failure.

---

## Pre-flight invariants

The installer refuses to run unless:

- **CWD has an `.xcodeproj` / `.xcworkspace` / `Package.swift`**
  (scope guard — same as v1/v2)
- **Path is ASCII-only, no spaces**
  Born from the path `Dashka-dual-chatpl-swift /Dashka/` that corrupted
  pbxproj. Now caught at pre-flight with a clear message.
- **For every file in the archive, parent folder exists on disk**
  Architect must create the topology first. Missing folder → installer
  pauses with explicit instruction:
  *"Create group `Domain/Model` in Xcode and the folder on disk, then retry."*

---

## Per-file gate UX

```
═══════════════════════════════════════════════════════════════
[3/26]  Install Dashka/Domain/Model/LangCode.swift
═══════════════════════════════════════════════════════════════

  Target:
    ./Dashka/Domain/Model/LangCode.swift
    11 lines · 312 bytes · sha256:a4f8c2e1b3d5e789

  Pre-flight checks:
    ✓  Parent folder exists on disk: Dashka/Domain/Model/
    ✓  File does not yet exist

  Preview:
    │ import Foundation
    │
    │ /// Mirrors the `LangCode` enum from Android `LangCode.kt`...
    │ public enum LangCode: String, CaseIterable, Codable, Sendable, Hashable {
    │     case ru, pl, en, de, fr, it, es, zh, lt, lv, ua
    │ }

  [Y] write  [D] full diff  [S] skip  [P] pause  [N] stop  [R] rollback all  > Y

   ✅ written to disk: Dashka/Domain/Model/LangCode.swift

────────────────────────────────────────────────────────────────
  ⚠ MANUAL STEP IN XCODE
────────────────────────────────────────────────────────────────

  Now in Xcode:
    1. Right-click group 'Model'
    2. Add Files to "Dashka"...
    3. Select:  LangCode.swift
    4. ✓ Add to targets: Dashka  (verify Target Membership)
    5. ⌘B  build

  Build verification:
    [Y] build is green   [N] build is RED → rollback this file   [P] pause  > Y

   ✓ confirmed green. 23 remaining.
```

---

## Commands

```bash
# Start or resume a sprint install
node solar-apply-swift-v3.js sprint-1-ios-text-translate.tar.gz

# Show what's been applied / skipped / failed so far
node solar-apply-swift-v3.js sprint-1-ios-text-translate --status

# Clear progress journal (start over)
node solar-apply-swift-v3.js sprint-1-ios-text-translate --reset
```

The journal lives at `.solar-progress/<task>.json`. It tracks:

```json
{
  "task": "sprint-1-ios-text-translate",
  "started_at": "2026-05-31T12:14:00Z",
  "last_touch_at": "2026-05-31T12:47:00Z",
  "applied": [
    { "file": "Dashka/Domain/Model/LangCode.swift",
      "ts": "...", "sha256": "...", "backup": null }
  ],
  "skipped": [],
  "failed":  [],
  "pending": [ "Dashka/Domain/Model/Direction.swift", ... ]
}
```

After Pause [P] or Stop [N], simply re-run the same command — the
installer picks up where it stopped.

---

## Dependency order

Files are processed in this fixed order (minimizes "Cannot find type"
errors as the architect installs incrementally):

```
1.  Domain/Model/*.swift            ← no dependencies
2.  Domain/Repository/*.swift       ← depend on models
3.  Domain/UseCase/*.swift          ← depend on repository protocols
4.  Data/Api/DTO/*.swift            ← Codable DTOs
5.  Data/Api/*.swift                ← API client
6.  Data/Repository/*.swift         ← concrete implementations
7.  Data/*.swift                    ← other data layer
8.  Presentation/Theme/*.swift      ← design tokens
9.  Presentation/.../Components/    ← reusable widgets
10. Presentation/Translator/*.swift ← screen + view model
11. Presentation/*.swift            ← other presentation
12. AppContainer.swift              ← DI (depends on everything)
13. *App.swift                      ← @main (depends on AppContainer)
14. README*.md                      ← docs last
```

Architect can override by [S]kipping a file and choosing to do something
else first; the journal records the skip.

---

## What v3 deliberately does NOT do

- ❌ **Never touches `project.pbxproj`** — architect's domain
- ❌ **Never adds files to Xcode target membership** — architect does it
- ❌ **Never runs `xcodebuild build`** — architect runs ⌘B in Xcode
- ❌ **Never creates folders on disk** — architect creates topology first
- ❌ **Never bulk-applies** — every single file is its own gate
- ❌ **Never deletes files automatically** — `[R] rollback all` is explicit only

These are not limitations. They are **invariants**. Each one is a lesson
paid for in debugging time.

---

## What's preserved from v1/v2

- `.swift / .plist / .xcconfig / .json / .md` extension filter
- Ignored: `DerivedData / build / .git / xcuserdata / node_modules` etc.
- Kimi PATCH invariant — installer never silently overwrites without [Y]
- Scope guard refuses to run outside Xcode projects
- Self-trap protection: `.solar-progress/` excluded from invariant checks

## What's NEW in v3

- **Per-file gate** (two confirmations per file: write + build)
- **Progress journal** (persistent across runs, supports resume)
- **Per-file rollback** (single bad file doesn't void prior progress)
- **Path sanitization** (refuse non-ASCII / whitespace in CWD)
- **Parent-folder existence check** (refuse if architect hasn't created topology)
- **Dependency-aware ordering** (minimize cascading compile errors)
- **No git operations** (architect commits manually after sprint complete)

The git branch/commit/PR workflow from v2 is a **separate concern** for v3.
After all files are applied and confirmed green, architect runs:

```bash
git add .
git commit -m "feat(iOS): apply sprint-1-ios-text-translate"
git push -u origin sprint/sprint-1-ios-text-translate
gh pr create
```

v2's git orchestration was useful for cleanly-bulk-applicable code; for
iOS, separating concerns keeps the human gate explicit.

---

## Exit codes

| Code | Meaning |
|---|---|
| 0 | clean completion, pause, or stop |
| 1 | scope check failed / operator quit |
| 2 | archive missing or unreadable |
| 3 | pre-flight failed (path has spaces, non-ASCII) |
| 4 | file write failed (disk full, permissions) |

---

## Audit chain (Solar Team v3.0)

```
Claude (engineer)    — generates archive, dependency-ordered
   ↓
Kimi (audit)         — verifies per-file gate behavior, rollback correctness
   ↓
Solana (audit)       — operator UX of the two-gate flow
   ↓
Qwen 2.5 72B         — concurrency / race conditions in journal writes
   ↓
Dashka (coordinator) — synthesis, GO/HOLD on installer
   ↓
Leanid (architect)   — final decision per file at every gate
```

---

## Versioning

| Version | Date | Headline change |
|---|---|---|
| 1.0     | 2026-05-30 | File installer, sticky [A] for NEW |
| 2.0     | 2026-05-30 | Git branch + commit + PR + M/K/R decision |
| **3.0** | 2026-05-31 | **Per-file gates, build verification, progress journal, topology pre-flight** |

Next planned:

- **3.1** — automated `xcodebuild -list` between files to detect target
  membership errors before architect does ⌘B
- **3.2** — parallel mode: architect can stage 3-4 files in Xcode, then
  batch-confirm. Useful for trivial domain enums.
- **4.0** — same shape for Kotlin/Android (`solar-apply-kotlin-v3`)

---

## The lesson, distilled

> **Code can be generated. Topology cannot be guessed.**
>
> An iOS installer that respects this invariant doesn't need to be
> clever. It needs to be patient, interruptible, and honest about which
> half of the job belongs to the architect.
