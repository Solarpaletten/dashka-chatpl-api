#!/usr/bin/env node
// solar-apply-swift-v3.js — Solar Sprint Incremental Installer (Swift/Xcode)
// ═══════════════════════════════════════════════════════════════════════════
//
// CONSTITUTIONAL RULE (Solar Team v3.0):
//   iOS installer MUST be incremental and interruptible.
//   No bulk apply for Swift/Xcode. Every file gets its own gate.
//
// ─── Design ─────────────────────────────────────────────────────────────────
// For each file in the archive (in dependency order):
//   1. Show preview + target path + pre-flight checks
//   2. Architect confirms write [Y/D/S/N/R]
//   3. Write to disk
//   4. Show Xcode manual-action instructions
//   5. Architect confirms build is green [Y/N/P]
//   6. On [N] → rollback THIS file only (last write reversed)
//      On [P] → save progress + exit cleanly (resume later)
//      On [Y] → move to next file
//
// ─── Pre-flight invariants ──────────────────────────────────────────────────
//   ✓ CWD has *.xcodeproj or *.xcworkspace (scope guard)
//   ✓ CWD absolute path is ASCII-only, no spaces (lesson from
//     /Dashka-dual-chatpl-swift /Dashka/ disaster)
//   ✓ For each file's parent directory: must exist on disk
//     (architect must create the folder topology first — Dashka's rule)
//
// ─── Progress journal ───────────────────────────────────────────────────────
//   .solar-progress/<task>.json  — persistent state across runs
//   Allows resume after pause/quit/crash:
//     - applied: [{file, ts, sha256}]
//     - skipped: [file]
//     - failed:  [{file, ts, reason}]
//     - pending: [file]
//
// ─── What v3 does NOT do (by design) ────────────────────────────────────────
//   ❌ Does NOT touch project.pbxproj  (architect's domain)
//   ❌ Does NOT add files to Xcode target membership  (architect does it)
//   ❌ Does NOT run xcodebuild build  (architect does ⌘B in Xcode)
//   ❌ Does NOT create folders  (architect creates topology first)
//   ❌ Does NOT bulk-apply  (every file is its own gate)
//
// ─── Usage ──────────────────────────────────────────────────────────────────
//   node solar-apply-swift-v3.js <sprint.tar.gz>           start or resume
//   node solar-apply-swift-v3.js <task-name> --status      show progress
//   node solar-apply-swift-v3.js <task-name> --reset       clear progress journal
//   node solar-apply-swift-v3.js --help
//
// ─── Exit codes ─────────────────────────────────────────────────────────────
//   0 — clean completion or paused by architect
//   1 — operator quit / scope check failed
//   2 — archive missing / unreadable
//   3 — pre-flight failed (path has spaces, missing parent dirs, etc.)
//   4 — file write failed (disk full, permissions)
// ═══════════════════════════════════════════════════════════════════════════

const fs       = require('fs');
const path     = require('path');
const crypto   = require('crypto');
const readline = require('readline');
const { execSync, spawnSync } = require('child_process');

// ─── CLI args ──────────────────────────────────────────────────────────────
const ARCHIVE_OR_TASK = process.argv[2];
const SHOW_STATUS = process.argv.includes('--status');
const RESET       = process.argv.includes('--reset');
const HELP        = process.argv.includes('--help') || !ARCHIVE_OR_TASK;

const ROOT         = process.cwd();
const PROGRESS_DIR = path.join(ROOT, '.solar-progress');

// ─── Colors ────────────────────────────────────────────────────────────────
const C = {
  reset:'\x1b[0m',     red:'\x1b[31m',    green:'\x1b[32m',
  yellow:'\x1b[33m',   blue:'\x1b[34m',   cyan:'\x1b[36m',
  magenta:'\x1b[35m',  bold:'\x1b[1m',    dim:'\x1b[2m',
};
const c   = (clr, s) => `${clr}${s}${C.reset}`;
const sep = (ch='─', n=72) => c(C.dim, ch.repeat(n));

// ─── Readline ──────────────────────────────────────────────────────────────
const rl  = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise(r => rl.question(q, r));
const closeRL = () => { try { rl.close(); } catch {} };

// ─── Banner & usage ────────────────────────────────────────────────────────
function banner() {
  console.log('');
  console.log(c(C.bold + C.cyan, '🛰️  Solar Apply Swift — v3.0'));
  console.log(c(C.dim, '   Incremental Swift installer with per-file build gates'));
  console.log(c(C.dim, '   Solar Team v3.0 · Windows-driver-style: one file at a time'));
  console.log('');
}

function usage() {
  console.log(c(C.bold, 'USAGE:'));
  console.log('  node solar-apply-swift-v3.js <sprint.tar.gz>      start / resume install');
  console.log('  node solar-apply-swift-v3.js <task-name> --status show progress journal');
  console.log('  node solar-apply-swift-v3.js <task-name> --reset  clear progress journal');
  console.log('');
  console.log(c(C.bold, 'CONSTITUTIONAL RULES:'));
  console.log('  • Architect creates Xcode groups + folder topology BEFORE running.');
  console.log('  • Installer writes one file → architect adds to Xcode + builds → confirms.');
  console.log('  • Build red → installer rolls back THAT file only, prior progress preserved.');
  console.log('  • Architect can pause [P] at any time; progress journal persists.');
  console.log('');
}

// ─── Pre-flight ────────────────────────────────────────────────────────────
function scopeOK() {
  try {
    const entries = fs.readdirSync(ROOT);
    return entries.some(e => e.endsWith('.xcodeproj'))
        || entries.some(e => e.endsWith('.xcworkspace'))
        || entries.includes('Package.swift');
  } catch { return false; }
}

function pathHasIssues() {
  // Lesson from yesterday's disaster: a SPACE in the absolute path corrupts
  // pbxproj parsers in subtle ways. Refuse to run.
  const issues = [];
  if (/\s/.test(ROOT))            issues.push('whitespace in path');
  if (/[^\x00-\x7F]/.test(ROOT))  issues.push('non-ASCII characters in path');
  if (/['"`&$()\[\]{}*?<>|;]/.test(ROOT)) issues.push('shell-special characters in path');
  return issues;
}

function refusePath(issues) {
  console.log(c(C.red, '\n❌ Pre-flight FAILED — path is unsafe for Xcode:\n'));
  console.log(c(C.dim, `   CWD: ${ROOT}`));
  console.log(c(C.dim, `   Issues: ${issues.join(', ')}`));
  console.log('');
  console.log(c(C.yellow, '   Xcode handles non-ASCII / spaces poorly in project paths.'));
  console.log(c(C.yellow, '   Move the project to a clean path before retrying.\n'));
  console.log(c(C.dim, '   Suggested target:'));
  console.log(c(C.dim, '     ~/Documents/ITproject/Dashka-IOS/Dashka/\n'));
}

// ─── Archive extraction ────────────────────────────────────────────────────
function extract(archivePath) {
  if (!fs.existsSync(archivePath)) {
    console.log(c(C.red, `\n❌ Archive not found: ${archivePath}\n`));
    return null;
  }
  const tmp = `/tmp/sas3_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
  fs.mkdirSync(tmp, { recursive: true });
  try {
    execSync(`tar -xzf "${archivePath}" -C "${tmp}" --strip-components=1`, { stdio: 'pipe' });
    return tmp;
  } catch {
    try {
      execSync(`tar -xzf "${archivePath}" -C "${tmp}"`, { stdio: 'pipe' });
      return tmp;
    } catch (e) {
      console.log(c(C.red, `\n❌ Failed to extract: ${e.message}\n`));
      return null;
    }
  }
}

const ALLOWED = new Set(['.swift', '.plist', '.xcconfig', '.json', '.md']);
const IGNORE_SEGS = new Set(['DerivedData','build','.git','xcuserdata','node_modules','.solar-backups','.solar-history','.solar-progress','.DS_Store']);
const SKIP_NAMES  = new Set(['solar-apply.js','solar-apply-swift.js','solar-apply-swift-v2.js','solar-apply-swift-v3.js','README_APPLY_SWIFT.md','README_APPLY_SWIFT_V2.md','README_APPLY_SWIFT_V3.md','manifest.json']);

function isAllowedExt(rel) { return ALLOWED.has(path.extname(rel).toLowerCase()); }
function isIgnored(rel)    {
  const segs = rel.split(path.sep);
  for (const s of segs) if (IGNORE_SEGS.has(s)) return true;
  if (SKIP_NAMES.has(path.basename(rel))) return true;
  return false;
}

function collectFiles(dir, base = dir, out = []) {
  let entries;
  try { entries = fs.readdirSync(dir); } catch { return out; }
  for (const e of entries) {
    const full = path.join(dir, e);
    let st;
    try { st = fs.statSync(full); } catch { continue; }
    if (st.isDirectory()) {
      if (IGNORE_SEGS.has(e)) continue;
      collectFiles(full, base, out);
    } else {
      const rel = path.relative(base, full);
      if (isIgnored(rel) || !isAllowedExt(rel)) continue;
      out.push(rel);
    }
  }
  return out;
}

// Dependency-aware sort: domain models first, then repos, use cases,
// API/data, then presentation. This minimizes "Cannot find type" errors
// as the architect installs file by file.
function sortByDependency(files) {
  const orderOf = (f) => {
    if (f.includes('Domain/Model/'))          return 1;
    if (f.includes('Domain/Repository/'))     return 2;
    if (f.includes('Domain/UseCase/'))        return 3;
    if (f.includes('Data/Api/DTO/'))          return 4;
    if (f.includes('Data/Api/'))              return 5;
    if (f.includes('Data/Repository/'))       return 6;
    if (f.includes('Data/'))                  return 7;
    if (f.includes('Presentation/Theme/'))    return 8;
    if (f.includes('Presentation/Translator/Components/')) return 9;
    if (f.includes('Presentation/Translator/'))            return 10;
    if (f.includes('Presentation/'))          return 11;
    if (f.endsWith('AppContainer.swift'))     return 12;
    if (f.endsWith('App.swift'))              return 13;  // @main last
    if (f.endsWith('.md'))                    return 14;  // docs last
    return 5;
  };
  return [...files].sort((a, b) => {
    const oa = orderOf(a), ob = orderOf(b);
    if (oa !== ob) return oa - ob;
    return a.localeCompare(b);
  });
}

// ─── Progress journal ──────────────────────────────────────────────────────
function journalPath(taskName) {
  return path.join(PROGRESS_DIR, `${taskName}.json`);
}

function loadJournal(taskName) {
  const p = journalPath(taskName);
  if (!fs.existsSync(p)) return null;
  try { return JSON.parse(fs.readFileSync(p, 'utf-8')); }
  catch { return null; }
}

function saveJournal(taskName, j) {
  fs.mkdirSync(PROGRESS_DIR, { recursive: true });
  fs.writeFileSync(journalPath(taskName), JSON.stringify(j, null, 2));
}

function sha256(content) {
  return crypto.createHash('sha256').update(content).digest('hex').slice(0, 16);
}

// ─── Status command ────────────────────────────────────────────────────────
function showStatus(taskName) {
  const j = loadJournal(taskName);
  if (!j) {
    console.log(c(C.dim, `\nNo progress journal for task '${taskName}'.\n`));
    return;
  }
  console.log(sep('═'));
  console.log(c(C.bold, `📋 PROGRESS — ${taskName}`));
  console.log(sep('═'));
  console.log(`   Started:    ${c(C.dim, j.started_at)}`);
  console.log(`   Last touch: ${c(C.dim, j.last_touch_at)}`);
  console.log(`   Total:      ${j.applied.length + j.skipped.length + j.failed.length + j.pending.length}`);
  console.log(`   ${c(C.green,  '✓ Applied:')}  ${j.applied.length}`);
  console.log(`   ${c(C.dim,    '⏭  Skipped:')}  ${j.skipped.length}`);
  console.log(`   ${c(C.red,    '✗ Failed:')}   ${j.failed.length}`);
  console.log(`   ${c(C.yellow, '○ Pending:')}  ${j.pending.length}`);
  console.log('');
  if (j.applied.length > 0) {
    console.log(c(C.bold, 'Applied:'));
    j.applied.forEach(a => console.log(c(C.green, `   ✓ ${a.file}`)));
  }
  if (j.failed.length > 0) {
    console.log(c(C.bold, '\nFailed:'));
    j.failed.forEach(f => console.log(c(C.red, `   ✗ ${f.file}  — ${f.reason}`)));
  }
  if (j.pending.length > 0) {
    console.log(c(C.bold, '\nPending (next up first):'));
    j.pending.slice(0, 5).forEach(p => console.log(c(C.yellow, `   ○ ${p}`)));
    if (j.pending.length > 5) console.log(c(C.dim, `   ... +${j.pending.length - 5} more`));
  }
  console.log('');
}

// ─── File preview ──────────────────────────────────────────────────────────
function preview(content, lines = 8) {
  const split = content.split('\n');
  const head = split.slice(0, lines);
  const out  = head.map(l => c(C.dim, '   │ ') + l).join('\n');
  if (split.length > lines) {
    return out + '\n' + c(C.dim, `   │ ... (+${split.length - lines} more lines)`);
  }
  return out;
}

// ─── Per-file gate (the heart of v3) ───────────────────────────────────────
async function fileGate(idx, total, relPath, content, taskName, journal) {
  console.log('');
  console.log(sep('═'));
  console.log(c(C.bold, `[${idx}/${total}]  Install ${c(C.cyan, relPath)}`));
  console.log(sep('═'));

  const destAbs   = path.join(ROOT, relPath);
  const parentDir = path.dirname(destAbs);
  const parentRel = path.relative(ROOT, parentDir);
  const parentExists = fs.existsSync(parentDir);
  const fileExists   = fs.existsSync(destAbs);
  const lineCount    = content.split('\n').length;
  const byteSize     = Buffer.byteLength(content, 'utf-8');

  // Pre-flight per-file
  console.log(c(C.bold, '\n  Target:'));
  console.log(`    ${c(C.dim, destAbs.replace(ROOT, '.'))}`);
  console.log(`    ${lineCount} lines · ${byteSize} bytes · sha256:${sha256(content)}`);

  console.log(c(C.bold, '\n  Pre-flight checks:'));
  console.log(`    ${parentExists ? c(C.green, '✓') : c(C.red, '✗')}  Parent folder exists on disk: ${c(C.dim, parentRel + '/')}`);
  console.log(`    ${!fileExists  ? c(C.green, '✓') : c(C.yellow, '⚠')}  File does not yet exist (or will overwrite)`);

  if (!parentExists) {
    console.log(c(C.red, '\n  ❌ Parent folder missing.'));
    console.log(c(C.yellow, `\n  ARCHITECT ACTION:`));
    console.log(c(C.yellow, `    Create the Xcode group + physical folder for:`));
    console.log(c(C.yellow, `    ${parentRel}/`));
    console.log(c(C.dim,    `    (Right-click parent group in Xcode → New Group, AND mkdir on disk)`));
    console.log('');
    const a = (await ask(c(C.bold, '  [Y] I created it, retry this file  [S] skip  [P] pause  [N] stop  > '))).toLowerCase().trim();
    if (a === 'y') return { action: 'retry' };
    if (a === 's') return { action: 'skip' };
    if (a === 'p') return { action: 'pause' };
    return { action: 'stop' };
  }

  // Preview
  console.log(c(C.bold, '\n  Preview:'));
  console.log(preview(content));

  // Decision
  console.log('');
  const choices = '[Y] write  [D] full diff  [S] skip  [P] pause  [N] stop  [R] rollback all';
  const ans = (await ask(c(C.bold, `  ${choices}  > `))).toLowerCase().trim();

  if (ans === 'd') {
    console.log('');
    if (fileExists) {
      const old = fs.readFileSync(destAbs, 'utf-8');
      showDiff(old, content);
    } else {
      console.log(c(C.green, '   (NEW FILE — full content:)\n'));
      content.split('\n').forEach(l => console.log(c(C.dim, '   ') + l));
    }
    const a2 = (await ask(c(C.bold, '\n  [Y] write  [S] skip  [P] pause  [N] stop  > '))).toLowerCase().trim();
    if (a2 === 'y') return { action: 'write' };
    if (a2 === 's') return { action: 'skip' };
    if (a2 === 'p') return { action: 'pause' };
    if (a2 === 'r') return { action: 'rollback' };
    return { action: 'stop' };
  }

  if (ans === 'y') return { action: 'write' };
  if (ans === 's') return { action: 'skip' };
  if (ans === 'p') return { action: 'pause' };
  if (ans === 'r') return { action: 'rollback' };
  return { action: 'stop' };
}

function showDiff(oldTxt, newTxt) {
  const t1 = `/tmp/sas3_old_${Date.now()}`;
  const t2 = `/tmp/sas3_new_${Date.now()}`;
  fs.writeFileSync(t1, oldTxt);
  fs.writeFileSync(t2, newTxt);
  try { execSync(`diff -u ${t1} ${t2}`, { encoding: 'utf-8' }); }
  catch (e) {
    for (const l of (e.stdout || '').split('\n').slice(2)) {
      if      (l.startsWith('+'))  process.stdout.write(c(C.green, l) + '\n');
      else if (l.startsWith('-'))  process.stdout.write(c(C.red,   l) + '\n');
      else if (l.startsWith('@@')) process.stdout.write(c(C.cyan,  l) + '\n');
      else                         process.stdout.write(c(C.dim,   l) + '\n');
    }
  } finally {
    try { fs.unlinkSync(t1); fs.unlinkSync(t2); } catch {}
  }
}

// ─── Build verification gate (post-write) ──────────────────────────────────
async function buildGate(relPath, parentRel) {
  console.log('');
  console.log(sep('─'));
  console.log(c(C.bold + C.magenta, '  ⚠ MANUAL STEP IN XCODE'));
  console.log(sep('─'));
  console.log(c(C.bold, '\n  Now in Xcode:'));
  console.log(`    1. ${c(C.cyan, `Right-click group '${path.basename(parentRel)}'`)}`);
  console.log(`    2. ${c(C.cyan, `Add Files to "Dashka"...`)}`);
  console.log(`    3. ${c(C.cyan, `Select:  ${path.basename(relPath)}`)}`);
  console.log(`    4. ${c(C.cyan, `✓ Add to targets: Dashka`)}  (verify Target Membership)`);
  console.log(`    5. ${c(C.cyan, `⌘B  build`)}`);
  console.log('');
  console.log(c(C.bold, '  Build verification:'));
  const ans = (await ask(c(C.bold, '    [Y] build is green   [N] build is RED → rollback this file   [P] pause  > '))).toLowerCase().trim();
  return ans;  // 'y' | 'n' | 'p' (or other = treat as pause)
}

// ─── Rollback helpers ──────────────────────────────────────────────────────
function rollbackOneFile(relPath, backupPath) {
  const dest = path.join(ROOT, relPath);
  if (backupPath && fs.existsSync(backupPath)) {
    fs.copyFileSync(backupPath, dest);
    console.log(c(C.yellow, `   ↩ restored previous content of ${relPath}`));
  } else {
    if (fs.existsSync(dest)) {
      fs.unlinkSync(dest);
      console.log(c(C.yellow, `   ↩ removed new file ${relPath}`));
    }
  }
}

function rollbackAll(journal) {
  console.log('');
  console.log(c(C.yellow + C.bold, '↩ ROLLBACK — undoing all applied files in this run'));
  for (const a of [...journal.applied].reverse()) {
    rollbackOneFile(a.file, a.backup);
  }
  console.log(c(C.green, `\n   ✅ rollback complete (${journal.applied.length} files reverted)`));
}

// ─── Main ──────────────────────────────────────────────────────────────────
async function main() {
  banner();

  if (HELP) { usage(); closeRL(); return; }

  // --status / --reset commands
  if (SHOW_STATUS) {
    const task = ARCHIVE_OR_TASK.replace(/\.tar\.gz$/, '');
    showStatus(task);
    closeRL();
    return;
  }
  if (RESET) {
    const task = ARCHIVE_OR_TASK.replace(/\.tar\.gz$/, '');
    const p = journalPath(task);
    if (fs.existsSync(p)) {
      fs.unlinkSync(p);
      console.log(c(C.green, `\n   ✓ Journal cleared for ${task}\n`));
    } else {
      console.log(c(C.dim, `\n   No journal to clear for ${task}\n`));
    }
    closeRL();
    return;
  }

  // Scope checks
  if (!scopeOK()) {
    console.log(c(C.red, '\n❌ Scope check failed — CWD is not a Swift/Xcode project.'));
    console.log(c(C.dim, `   CWD: ${ROOT}\n`));
    closeRL();
    process.exit(1);
  }

  const pathIssues = pathHasIssues();
  if (pathIssues.length > 0) {
    refusePath(pathIssues);
    closeRL();
    process.exit(3);
  }

  const archive = ARCHIVE_OR_TASK;
  const taskName = path.basename(archive).replace(/\.tar\.gz$/, '');

  // Extract
  const tmpDir = extract(archive);
  if (!tmpDir) { closeRL(); process.exit(2); }

  const allFiles = collectFiles(tmpDir);
  const sorted   = sortByDependency(allFiles);

  // Load or initialize journal
  let journal = loadJournal(taskName);
  const resuming = journal !== null;

  if (resuming) {
    console.log(c(C.cyan, `📋 Resuming task '${taskName}'`));
    console.log(c(C.dim, `   Previously: ${journal.applied.length} applied, ${journal.skipped.length} skipped, ${journal.pending.length} pending\n`));
  } else {
    journal = {
      task:           taskName,
      started_at:     new Date().toISOString(),
      last_touch_at:  new Date().toISOString(),
      applied:        [],
      skipped:        [],
      failed:         [],
      pending:        sorted,
    };
    saveJournal(taskName, journal);
  }

  // Start banner
  console.log(sep('═'));
  console.log(c(C.bold, `🚀 SOLAR APPLY SWIFT v3 — ${taskName}`));
  console.log(sep('═'));
  console.log(`   Files in archive: ${sorted.length}`);
  console.log(`   Already applied:  ${journal.applied.length}`);
  console.log(`   Remaining:        ${journal.pending.length}`);
  console.log(c(C.dim, `   Progress journal: .solar-progress/${taskName}.json\n`));

  if (journal.pending.length === 0) {
    console.log(c(C.green, '   ✅ Nothing pending — all files already handled.\n'));
    fs.rmSync(tmpDir, { recursive: true, force: true });
    closeRL();
    return;
  }

  if (!resuming) {
    const ok = (await ask(c(C.bold, '🛡 Architect ready to start? [Y] go  [Q] quit  > '))).toLowerCase().trim();
    if (ok !== 'y' && ok !== '') {
      console.log(c(C.dim, '\n   Cancelled.\n'));
      fs.rmSync(tmpDir, { recursive: true, force: true });
      closeRL();
      return;
    }
  }

  // ─── The per-file loop ──────────────────────────────────────────────────
  const total = journal.applied.length + journal.skipped.length + journal.failed.length + journal.pending.length;

  while (journal.pending.length > 0) {
    const relPath = journal.pending[0];
    const idx = journal.applied.length + journal.skipped.length + journal.failed.length + 1;
    const srcAbs = path.join(tmpDir, relPath);

    let content;
    try { content = fs.readFileSync(srcAbs, 'utf-8'); }
    catch (e) {
      console.log(c(C.red, `\n   ✗ Cannot read source for ${relPath}: ${e.message}`));
      journal.failed.push({ file: relPath, ts: new Date().toISOString(), reason: 'source unreadable' });
      journal.pending.shift();
      saveJournal(taskName, journal);
      continue;
    }

    // GATE 1 — pre-write architect decision
    const decision = await fileGate(idx, total, relPath, content, taskName, journal);

    if (decision.action === 'retry') {
      continue;  // re-evaluate this file from scratch (parent dir may now exist)
    }
    if (decision.action === 'skip') {
      journal.skipped.push(relPath);
      journal.pending.shift();
      journal.last_touch_at = new Date().toISOString();
      saveJournal(taskName, journal);
      console.log(c(C.dim, '   ⏭ skipped\n'));
      continue;
    }
    if (decision.action === 'pause') {
      console.log(c(C.cyan, '\n   ⏸ Paused. Run the same command again to resume.\n'));
      fs.rmSync(tmpDir, { recursive: true, force: true });
      closeRL();
      return;
    }
    if (decision.action === 'stop') {
      console.log(c(C.dim, '\n   ⏹ Stopped. Use --status to review, --reset to start over.\n'));
      fs.rmSync(tmpDir, { recursive: true, force: true });
      closeRL();
      return;
    }
    if (decision.action === 'rollback') {
      rollbackAll(journal);
      journal.applied = [];
      journal.skipped = [];
      journal.failed  = [];
      saveJournal(taskName, journal);
      console.log(c(C.dim, '\n   Journal reset to pending state. Run again to retry.\n'));
      fs.rmSync(tmpDir, { recursive: true, force: true });
      closeRL();
      return;
    }

    // decision.action === 'write'
    const destAbs    = path.join(ROOT, relPath);
    const parentRel  = path.relative(ROOT, path.dirname(destAbs));
    const hadBefore  = fs.existsSync(destAbs);
    let backupPath   = null;
    if (hadBefore) {
      backupPath = path.join(PROGRESS_DIR, taskName + '-backups', relPath);
      fs.mkdirSync(path.dirname(backupPath), { recursive: true });
      fs.copyFileSync(destAbs, backupPath);
    }

    try {
      fs.writeFileSync(destAbs, content);
      console.log(c(C.green, `\n   ✅ written to disk: ${relPath}`));
    } catch (e) {
      console.log(c(C.red, `\n   ✗ write failed: ${e.message}`));
      journal.failed.push({ file: relPath, ts: new Date().toISOString(), reason: 'write failed: ' + e.message });
      journal.pending.shift();
      saveJournal(taskName, journal);
      continue;
    }

    // GATE 2 — post-write build verification
    const buildAns = await buildGate(relPath, parentRel);

    if (buildAns === 'y') {
      journal.applied.push({
        file: relPath,
        ts: new Date().toISOString(),
        sha256: sha256(content),
        backup: backupPath,
      });
      journal.pending.shift();
      journal.last_touch_at = new Date().toISOString();
      saveJournal(taskName, journal);
      console.log(c(C.green, `   ✓ confirmed green. ${journal.pending.length} remaining.\n`));
    } else if (buildAns === 'n') {
      console.log(c(C.yellow, '\n   ⚠ Build red — rolling back THIS file only'));
      rollbackOneFile(relPath, backupPath);
      journal.failed.push({
        file: relPath,
        ts: new Date().toISOString(),
        reason: 'build failed after write, rolled back',
      });
      journal.pending.shift();
      journal.last_touch_at = new Date().toISOString();
      saveJournal(taskName, journal);
      console.log(c(C.yellow, '   ⏸ Pausing — architect should investigate before continuing.'));
      console.log(c(C.dim,    `   Resume command: node solar-apply-swift-v3.js ${path.basename(archive)}\n`));
      fs.rmSync(tmpDir, { recursive: true, force: true });
      closeRL();
      return;
    } else {
      // pause or anything else
      console.log(c(C.cyan, '\n   ⏸ Paused after write but before build confirmation.'));
      console.log(c(C.dim,    '   The file IS on disk and the journal records it as applied-pending-verification.'));
      console.log(c(C.dim,    `   Resume: node solar-apply-swift-v3.js ${path.basename(archive)}\n`));
      // Don't mark as applied; leave at top of pending so next run re-asks.
      // But we've already written it, so add to backups so re-run sees it.
      saveJournal(taskName, journal);
      fs.rmSync(tmpDir, { recursive: true, force: true });
      closeRL();
      return;
    }
  }

  // ─── Done ───────────────────────────────────────────────────────────────
  console.log('');
  console.log(sep('═'));
  console.log(c(C.bold + C.green, `🎉 SPRINT COMPLETE — ${taskName}`));
  console.log(sep('═'));
  console.log(`   ${c(C.green,  '✓ Applied:')}  ${journal.applied.length}`);
  console.log(`   ${c(C.dim,    '⏭  Skipped:')}  ${journal.skipped.length}`);
  console.log(`   ${c(C.red,    '✗ Failed:')}   ${journal.failed.length}`);
  console.log('');
  console.log(c(C.dim, `   Journal preserved at: .solar-progress/${taskName}.json`));
  console.log(c(C.dim, `   (Architect may now: git add . && git commit -m "feat: sprint ${taskName}")\n`));

  fs.rmSync(tmpDir, { recursive: true, force: true });
  closeRL();
}

main().catch(err => {
  console.error(c(C.red, '\n💥 Unhandled error: ' + (err && err.message ? err.message : err)));
  if (err && err.stack) console.error(c(C.dim, err.stack));
  closeRL();
  process.exit(1);
});
