# Sprint 1A — iOS Dashka · minimal bootstrap

**Scope:** app opens, text field visible, translate button visible, build green.
**Files:** 3.
**No backend.** "Перевести" echoes input → output (Sprint 1B replaces with API).

---

## What's in this sprint

| File | Action | Purpose |
|---|---|---|
| `Dashka/DashkaApp.swift` | PATCH | `@main` wires `TranslatorScreen(viewModel:)` |
| `Dashka/Presentation/Translator/TranslatorScreen.swift` | NEW | Text field + 2 buttons + output area |
| `Dashka/Presentation/Translator/TranslatorViewModel.swift` | NEW | Two strings + placeholder translate |

### NOT in this sprint

- ❌ Backend / API / DashkaApi
- ❌ Clean Architecture (Domain/Data/Repository/UseCase layers)
- ❌ AppContainer / DI
- ❌ Direction toggle
- ❌ Error handling
- ❌ Theme / DashkaColors abstraction
- ❌ Microphone / TTS / Share / History
- ❌ Configs (xcconfig)
- ❌ Info.plist customization
- ❌ Foundation models (PaneState, MicState, etc.)

All of the above arrive in future incremental sprints, **one concern at a time**.

---

## Manual Xcode steps after apply

1. Open `Dashka.xcodeproj`
2. Drag-add `Dashka/Presentation/` folder into Project Navigator
   (Create groups, Add to target Dashka, **do NOT** copy)
3. Verify Target Membership ✅ Dashka on both new `.swift` files
4. ⌘B — expect green
5. ⌘R on simulator

## Acceptance — Sprint 1A

- [ ] App launches without crash
- [ ] "Дашка" title shows
- [ ] TextField visible and editable
- [ ] Typing enables "Перевести" button
- [ ] Tapping "Перевести" → output area shows the same text
- [ ] "Очистить" empties both
- [ ] No backend errors (there's no backend yet)

---

## Roadmap — what comes next, one step at a time

- **Sprint 1B** — add `DashkaApi` + `URLSession` call to `/api/translate`. One file added.
- **Sprint 1C** — add direction toggle (RU↔PL). One file edited.
- **Sprint 1D** — add error banner.
- Then Sprint 2A — mic.

**Rule:** each sprint = one concern. Council rejects anything larger.
