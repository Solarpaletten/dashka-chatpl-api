import SwiftUI

/// App entry point — minimal Sprint 1A wiring.
///
/// Sprint 1A scope: app launches, shows TranslatorScreen, builds green.
/// No DI container, no backend, no Clean Architecture layers.
/// All of that comes in future incremental sprints.
@main
struct DashkaApp: App {
    var body: some Scene {
        WindowGroup {
            TranslatorScreen(viewModel: TranslatorViewModel())
        }
    }
}
