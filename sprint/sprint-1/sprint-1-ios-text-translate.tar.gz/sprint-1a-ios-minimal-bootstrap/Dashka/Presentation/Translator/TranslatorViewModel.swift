import Foundation
import Observation

/// Sprint 1A ViewModel — minimal state.
///
/// Holds two strings (input + output) and a placeholder translate action
/// that just echoes input → output. No backend, no use cases, no API.
///
/// **Why so thin?** Sprint 1A goal is "app opens, build green". Backend
/// integration arrives in Sprint 1B. This file will grow incrementally,
/// one sprint at a time.
@MainActor
@Observable
final class TranslatorViewModel {
    var inputText: String = ""
    var outputText: String = ""

    func translate() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        // Sprint 1A placeholder: echo input.
        // Sprint 1B will replace this with a real API call.
        outputText = trimmed
    }

    func clear() {
        inputText = ""
        outputText = ""
    }
}
