import SwiftUI

/// Sprint 1A screen — minimal UI:
///   - Title "Дашка"
///   - Multi-line input TextField
///   - "Перевести" button (echoes input → output in Sprint 1A)
///   - "Очистить" button
///   - Output area
///
/// No mic, no direction toggle, no error banner, no Theme abstraction.
/// All of that arrives in future incremental sprints.
struct TranslatorScreen: View {

    @Bindable var viewModel: TranslatorViewModel

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                TextField(
                    "Введите текст",
                    text: $viewModel.inputText,
                    axis: .vertical
                )
                .lineLimit(3...6)
                .textFieldStyle(.roundedBorder)

                HStack(spacing: 12) {
                    Button("Очистить") {
                        viewModel.clear()
                    }
                    .buttonStyle(.bordered)
                    .frame(maxWidth: .infinity)

                    Button("Перевести") {
                        viewModel.translate()
                    }
                    .buttonStyle(.borderedProminent)
                    .frame(maxWidth: .infinity)
                    .disabled(
                        viewModel.inputText
                            .trimmingCharacters(in: .whitespacesAndNewlines)
                            .isEmpty
                    )
                }

                ScrollView {
                    Text(
                        viewModel.outputText.isEmpty
                            ? "Перевод появится здесь"
                            : viewModel.outputText
                    )
                    .font(.system(size: 17))
                    .foregroundColor(viewModel.outputText.isEmpty ? .secondary : .primary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(12)
                }
                .frame(minHeight: 100, maxHeight: 220)
                .background(Color(.secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 8))

                Spacer()
            }
            .padding()
            .navigationTitle("Дашка")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    TranslatorScreen(viewModel: TranslatorViewModel())
}
