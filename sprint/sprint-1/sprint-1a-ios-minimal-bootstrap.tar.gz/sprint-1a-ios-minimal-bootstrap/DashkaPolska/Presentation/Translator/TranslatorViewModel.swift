import Foundation
import Observation

/// Sprint 1A ViewModel — minimal state.
///
/// Two strings + placeholder translate. No backend, no use cases.
/// Sprint 1B will swap the echo for a real API call.
@MainActor
@Observable
final class TranslatorViewModel {
    var inputText: String = ""
    var outputText: String = ""

    func translate() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        // Sprint 1A placeholder: echo input.
        outputText = trimmed
    }

    func clear() {
        inputText = ""
        outputText = ""
    }
}
