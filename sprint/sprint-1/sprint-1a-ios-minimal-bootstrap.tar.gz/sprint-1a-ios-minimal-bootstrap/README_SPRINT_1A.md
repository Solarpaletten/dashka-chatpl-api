# Sprint 1A — DashkaPolska iOS · minimal bootstrap

**Project:** `DashkaPolska.xcodeproj`
**Scope:** app opens, text field visible, translate button visible, build green.
**Files:** 3 Swift + 1 README.
**No backend.** "Перевести" echoes input → output. Sprint 1B replaces with API.

---

## What's in this sprint

| File | Action | Purpose |
|---|---|---|
| `DashkaPolska/DashkaPolskaApp.swift` | PATCH | `@main` body → `TranslatorScreen(viewModel:)` |
| `DashkaPolska/Presentation/Translator/TranslatorScreen.swift` | NEW | TextField + 2 buttons + output area |
| `DashkaPolska/Presentation/Translator/TranslatorViewModel.swift` | NEW | Two strings + echo translate |

### NOT in this sprint

Backend, API, Clean Architecture layers, DI, direction toggle, error handling,
Theme abstraction, microphone, TTS, share, history, xcconfig, Info.plist
customization, foundation enums. **One concern per sprint.**

---

## Manual Xcode steps after `solar-apply-swift-v2` finishes writing files

Critical: paths must match what Xcode expects. **The folder `DashkaPolska/`
inside Project Navigator must contain the new `Presentation/` group — not
the project root.**

### Step-by-step

1. **Close Xcode completely** (⌘Q). This prevents stale in-memory state.

2. **Open `DashkaPolska.xcodeproj`** fresh.

3. **Check for red files** in Project Navigator (left pane). Red = broken
   reference. If you see any:
   - Right-click → **Delete** → **Remove Reference** (NOT "Move to Trash").
   - Especially: any stale `ContentView.swift` reference left from the
     Xcode template, or any duplicate `DashkaPolskaApp.swift` reference.

4. **In Finder**, open the folder where `DashkaPolskaApp.swift` lives
   (typically `DashkaPolska/DashkaPolska/` since Xcode usually nests the
   source folder one level inside the project folder).

   ⚠ **Verify physical paths first** before drag-add:
   ```bash
   ls DashkaPolska/Presentation/Translator/TranslatorScreen.swift
   ls DashkaPolska/Presentation/Translator/TranslatorViewModel.swift
   ```
   Both must exist on disk. If not — `solar-apply-swift-v2` wrote them
   somewhere else; check the apply output for the actual paths.

5. **Drag the `Presentation` folder** from Finder **into Project Navigator,
   directly under the `DashkaPolska` group** (NOT the project root). The
   group is the yellow folder icon with the same name as the project.

   In the dialog that appears:
   - ✅ **Create groups** (NOT "Create folder references")
   - ❌ **Uncheck "Copy items if needed"** (files are already on disk;
     copying would create duplicates and break paths)
   - ✅ **Add to targets: DashkaPolska**

6. **Verify Target Membership** for each new `.swift` file:
   - Select the file in Project Navigator
   - File Inspector (right pane, ⌥⌘1)
   - Target Membership section → **DashkaPolska** must be ✅
   - Repeat for both `TranslatorScreen.swift` and `TranslatorViewModel.swift`

7. **Clean DerivedData** (belt-and-suspenders against stale build cache):
   - ⌘⇧K (Product → Clean Build Folder), or
   - From terminal: `rm -rf ~/Library/Developer/Xcode/DerivedData/DashkaPolska-*`

8. **⌘B** Build — expect green.

9. **⌘R** Run on simulator.

---

## Acceptance — Sprint 1A

- [ ] App launches without crash
- [ ] "Dashka Polska" title visible at top
- [ ] TextField visible and editable
- [ ] Typing enables "Перевести" button
- [ ] Tapping "Перевести" → output area shows the same text
- [ ] "Очистить" empties both fields
- [ ] No backend errors (there's no backend yet)

---

## If build fails

**Red files in Project Navigator:** Remove Reference (NOT Move to Trash),
then drag-add again from Finder.

**"Unexpected input file" pointing at project root:** somewhere a parent
folder got added to Compile Sources. Target → Build Phases → Compile
Sources → find the bad entry → click `-` to remove.

**Path looks like `/DashkaPolska/DashkaPolska/...` (doubled):** when
drag-adding, the file was dropped at project root instead of inside the
group. Remove Reference, then re-drag making sure it lands under the
yellow `DashkaPolska` group icon, not the blue project icon.

**Rollback option always available** via solar-apply-swift-v2:
```bash
git checkout main
git branch -D solar/sprint-1a-ios-minimal-bootstrap
git tag --delete solar-checkpoint-sprint-1a-ios-minimal-bootstrap
```

---

## Roadmap — what comes next, one step at a time

- **Sprint 1B** — `DashkaApi.swift` + URLSession call. 1 NEW + 1 PATCH.
- **Sprint 1C** — direction toggle RU↔PL. 1 NEW + 1 PATCH.
- **Sprint 1D** — error banner. 1 PATCH.
- Then Sprint 2A — microphone.

**Rule:** each sprint = one concern. Council rejects anything larger.
